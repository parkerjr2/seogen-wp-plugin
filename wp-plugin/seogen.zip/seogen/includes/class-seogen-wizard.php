<?php
/**
 * SEOgen First Run Wizard
 * 
 * Guides users through initial setup and automates bulk page generation.
 * Does not modify existing functionality - only adds new guided workflow.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SEOgen_Wizard {
	const WIZARD_STATE_OPTION = 'seogen_wizard_state';
	const WIZARD_DISMISSED_OPTION = 'seogen_wizard_dismissed';
	
	/**
	 * Initialize wizard
	 */
	public function __construct() {
		// Admin hooks
		add_action( 'admin_menu', array( $this, 'add_wizard_menu' ) );
		add_action( 'admin_init', array( $this, 'maybe_redirect_to_wizard' ) );
		add_action( 'admin_notices', array( $this, 'show_wizard_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_wizard_assets' ) );
		
		// AJAX handlers
		add_action( 'wp_ajax_seogen_wizard_validate_step', array( $this, 'ajax_validate_step' ) );
		add_action( 'wp_ajax_seogen_wizard_advance_step', array( $this, 'ajax_advance_step' ) );
		add_action( 'wp_ajax_seogen_wizard_start_generation', array( $this, 'ajax_start_generation' ) );
		add_action( 'wp_ajax_seogen_wizard_process_batch', array( $this, 'ajax_process_batch' ) );
		add_action( 'wp_ajax_seogen_wizard_generation_progress', array( $this, 'ajax_generation_progress' ) );
		add_action( 'wp_ajax_seogen_wizard_skip_generation', array( $this, 'ajax_skip_generation' ) );
		add_action( 'wp_ajax_seogen_wizard_dismiss', array( $this, 'ajax_dismiss_wizard' ) );
		add_action( 'wp_ajax_seogen_wizard_reset', array( $this, 'ajax_reset_wizard' ) );
		
		// Admin-post handlers for form submissions
		add_action( 'admin_post_seogen_wizard_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_seogen_wizard_save_business', array( $this, 'handle_save_business' ) );
		
		// AJAX handlers for inline service/city management
		add_action( 'wp_ajax_seogen_wizard_add_service', array( $this, 'ajax_add_service' ) );
		add_action( 'wp_ajax_seogen_wizard_bulk_add_services', array( $this, 'ajax_bulk_add_services' ) );
		add_action( 'wp_ajax_seogen_wizard_delete_service', array( $this, 'ajax_delete_service' ) );
		add_action( 'wp_ajax_seogen_wizard_add_city', array( $this, 'ajax_add_city' ) );
		add_action( 'wp_ajax_seogen_wizard_delete_city', array( $this, 'ajax_delete_city' ) );
	}
	
	/**
	 * Get wizard state
	 * 
	 * @return array Wizard state data
	 */
	public function get_wizard_state() {
		$default_state = array(
			'completed' => false,
			'current_step' => 1,
			'steps_completed' => array(
				'settings' => false,
				'business' => false,
				'services' => false,
				'cities' => false,
			),
			'auto_generation' => array(
				'service_hubs' => 'pending',
				'service_pages' => 'pending',
				'city_hubs' => 'pending',
				'job_ids' => array(),
				'created_posts' => array(),
			),
		);
		
		$state = get_option( self::WIZARD_STATE_OPTION, $default_state );
		
		// Ensure all keys exist
		return wp_parse_args( $state, $default_state );
	}
	
	/**
	 * Update wizard state
	 * 
	 * @param array $updates State updates to merge
	 * @return bool Success
	 */
	public function update_wizard_state( $updates ) {
		$state = $this->get_wizard_state();
		$state = array_replace_recursive( $state, $updates );
		return update_option( self::WIZARD_STATE_OPTION, $state );
	}
	
	/**
	 * Check if wizard is complete
	 * 
	 * @return bool True if wizard completed
	 */
	public function is_wizard_complete() {
		$state = $this->get_wizard_state();
		return ! empty( $state['completed'] );
	}
	
	/**
	 * Check if wizard is dismissed
	 * 
	 * @return bool True if wizard dismissed
	 */
	public function is_wizard_dismissed() {
		return (bool) get_option( self::WIZARD_DISMISSED_OPTION, false );
	}
	
	/**
	 * Reset wizard state
	 * 
	 * @return bool Success
	 */
	public function reset_wizard() {
		delete_option( self::WIZARD_STATE_OPTION );
		delete_option( self::WIZARD_DISMISSED_OPTION );
		return true;
	}
	
	/**
	 * Add wizard menu item
	 */
	public function add_wizard_menu() {
		// Only show wizard menu if user can manage options
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		
		// Always show wizard menu for administrators
		// This allows re-running the wizard or accessing it even if completed/dismissed
		add_menu_page(
			__( 'Setup Wizard', 'seogen' ),
			__( 'Setup Wizard', 'seogen' ),
			'manage_options',
			'seogen-wizard',
			array( $this, 'render_wizard_page' ),
			'dashicons-admin-generic',
			3
		);
	}
	
	/**
	 * Maybe redirect to wizard on plugin activation
	 */
	public function maybe_redirect_to_wizard() {
		// Only redirect if wizard not completed and not dismissed
		if ( $this->is_wizard_complete() || $this->is_wizard_dismissed() ) {
			return;
		}
		
		// Check if this is a fresh activation (no settings saved)
		$settings = get_option( 'seogen_settings', array() );
		if ( empty( $settings ) ) {
			// Only redirect on admin pages, not AJAX
			if ( is_admin() && ! wp_doing_ajax() && ! isset( $_GET['page'] ) ) {
				// Check if we should redirect (use transient to prevent redirect loops)
				$redirect_key = 'seogen_wizard_redirect_' . get_current_user_id();
				if ( ! get_transient( $redirect_key ) ) {
					set_transient( $redirect_key, 1, 60 );
					wp_safe_redirect( admin_url( 'admin.php?page=seogen-wizard' ) );
					exit;
				}
			}
		}
	}
	
	/**
	 * Show wizard notice
	 */
	public function show_wizard_notice() {
		// Only show if wizard not completed and not dismissed
		if ( $this->is_wizard_complete() || $this->is_wizard_dismissed() ) {
			return;
		}
		
		// Don't show on wizard page itself
		if ( isset( $_GET['page'] ) && 'seogen-wizard' === $_GET['page'] ) {
			return;
		}
		
		// Only show to users who can manage options
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		
		$wizard_url = admin_url( 'admin.php?page=seogen-wizard' );
		?>
		<div class="notice notice-info is-dismissible seogen-wizard-notice">
			<p>
				<strong><?php esc_html_e( 'Welcome to Hyper Local!', 'seogen' ); ?></strong>
				<?php esc_html_e( 'Complete the setup wizard to get started with automated page generation.', 'seogen' ); ?>
			</p>
			<p>
				<a href="<?php echo esc_url( $wizard_url ); ?>" class="button button-primary">
					<?php esc_html_e( 'Start Setup Wizard', 'seogen' ); ?>
				</a>
				<a href="#" class="button seogen-wizard-dismiss">
					<?php esc_html_e( 'Dismiss', 'seogen' ); ?>
				</a>
			</p>
		</div>
		<script>
		jQuery(document).ready(function($) {
			$('.seogen-wizard-dismiss').on('click', function(e) {
				e.preventDefault();
				$.post(ajaxurl, {
					action: 'seogen_wizard_dismiss',
					_ajax_nonce: '<?php echo wp_create_nonce( 'seogen_wizard_dismiss' ); ?>'
				}, function() {
					$('.seogen-wizard-notice').fadeOut();
				});
			});
		});
		</script>
		<?php
	}
	
	/**
	 * Enqueue wizard assets
	 */
	public function enqueue_wizard_assets( $hook ) {
		// Only load on wizard page
		if ( 'toplevel_page_seogen-wizard' !== $hook ) {
			return;
		}
		
		wp_enqueue_style(
			'seogen-wizard',
			SEOGEN_PLUGIN_URL . 'assets/wizard.css',
			array(),
			SEOGEN_VERSION
		);
		
		wp_enqueue_script(
			'seogen-wizard',
			SEOGEN_PLUGIN_URL . 'assets/wizard.js',
			array( 'jquery' ),
			SEOGEN_VERSION,
			true
		);
		
		wp_localize_script(
			'seogen-wizard',
			'seogenWizard',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'seogen_wizard' ),
				'strings' => array(
					'validating' => __( 'Validating...', 'seogen' ),
					'saving' => __( 'Saving...', 'seogen' ),
					'generating' => __( 'Generating pages...', 'seogen' ),
					'error' => __( 'An error occurred. Please try again.', 'seogen' ),
				),
			)
		);
	}
	
	/**
	 * Render wizard page
	 */
	public function render_wizard_page() {
		// Migrate existing services to include hub field if missing
		$this->migrate_services_hub_field();
		
		$state = $this->get_wizard_state();
		$current_step = isset( $state['current_step'] ) ? (int) $state['current_step'] : 1;
		
		include SEOGEN_PLUGIN_DIR . 'templates/wizard-page.php';
	}
	
	/**
	 * Migrate existing services to include hub field
	 */
	private function migrate_services_hub_field() {
		$services = get_option( 'hyper_local_services_cache', array() );
		if ( empty( $services ) || ! is_array( $services ) ) {
			return;
		}
		
		$config = get_option( 'seogen_business_config', array() );
		$hub_categories = isset( $config['hub_categories'] ) && is_array( $config['hub_categories'] ) 
			? $config['hub_categories'] 
			: array( 'residential', 'commercial' );
		$default_hub = ! empty( $hub_categories ) ? $hub_categories[0] : 'residential';
		
		$updated = false;
		foreach ( $services as $idx => $service ) {
			// If service is a string, convert to array with hub
			if ( is_string( $service ) ) {
				$services[ $idx ] = array(
					'name' => $service,
					'hub' => $default_hub,
				);
				$updated = true;
			}
			// If service is array but missing hub, add default hub
			elseif ( is_array( $service ) && ! isset( $service['hub'] ) ) {
				$services[ $idx ]['hub'] = $default_hub;
				$updated = true;
			}
		}
		
		if ( $updated ) {
			update_option( 'hyper_local_services_cache', $services );
		}
	}
	
	/**
	 * Validate step
	 */
	public function validate_step( $step ) {
		switch ( $step ) {
			case 1:
				return $this->validate_step_settings();
			case 2:
				return $this->validate_step_business();
			case 3:
				return $this->validate_step_services();
			case 4:
				return $this->validate_step_cities();
			default:
				return array( 'valid' => false, 'message' => 'Invalid step' );
		}
	}
	
	/**
	 * Validate settings step
	 */
	public function validate_step_settings() {
		$settings = get_option( 'seogen_settings', array() );
		
		// Check if API URL and license key are set
		if ( empty( $settings['api_url'] ) ) {
			return array( 'valid' => false, 'message' => 'API URL is required' );
		}
		
		if ( empty( $settings['license_key'] ) ) {
			return array( 'valid' => false, 'message' => 'License Key is required' );
		}
		
		// Test API connection
		$api_url = trailingslashit( $settings['api_url'] ) . 'health';
		$response = wp_remote_get( $api_url, array( 'timeout' => 10 ) );
		
		if ( is_wp_error( $response ) ) {
			return array( 'valid' => false, 'message' => 'Cannot connect to API: ' . $response->get_error_message() );
		}
		
		$status_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code ) {
			return array( 'valid' => false, 'message' => 'API connection failed (HTTP ' . $status_code . ')' );
		}
		
		return array( 'valid' => true, 'message' => 'Settings validated successfully' );
	}
	
	/**
	 * Validate business setup step
	 */
	public function validate_step_business() {
		$config = get_option( 'seogen_business_config', array() );
		
		$required_fields = array( 'vertical', 'business_name', 'phone' );
		foreach ( $required_fields as $field ) {
			if ( empty( $config[ $field ] ) ) {
				return array( 'valid' => false, 'message' => ucfirst( str_replace( '_', ' ', $field ) ) . ' is required' );
			}
		}
		
		return array( 'valid' => true, 'message' => 'Business setup validated successfully' );
	}
	
	/**
	 * Validate services step
	 */
	public function validate_step_services() {
		$services = get_option( 'hyper_local_services_cache', array() );
		
		if ( empty( $services ) || ! is_array( $services ) ) {
			return array( 'valid' => false, 'message' => 'Please add at least 3 services' );
		}
		
		if ( count( $services ) < 3 ) {
			return array( 'valid' => false, 'message' => 'Please add at least 3 services (currently ' . count( $services ) . ')' );
		}
		
		return array( 'valid' => true, 'message' => 'Services validated successfully' );
	}
	
	/**
	 * Validate cities step
	 */
	public function validate_step_cities() {
		$cities = get_option( 'hyper_local_cities_cache', array() );
		
		if ( empty( $cities ) || ! is_array( $cities ) ) {
			return array( 'valid' => false, 'message' => 'Please add at least 3 cities' );
		}
		
		if ( count( $cities ) < 3 ) {
			return array( 'valid' => false, 'message' => 'Please add at least 3 cities (currently ' . count( $cities ) . ')' );
		}
		
		return array( 'valid' => true, 'message' => 'Cities validated successfully' );
	}
	
	/**
	 * AJAX: Validate step
	 */
	public function ajax_validate_step() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$step = isset( $_POST['step'] ) ? (int) $_POST['step'] : 0;
		$result = $this->validate_step( $step );
		
		if ( $result['valid'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}
	
	/**
	 * AJAX: Advance to next step
	 */
	public function ajax_advance_step() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$step = isset( $_POST['step'] ) ? (int) $_POST['step'] : 0;
		
		// Validate current step
		$validation = $this->validate_step( $step );
		if ( ! $validation['valid'] ) {
			wp_send_json_error( $validation );
		}
		
		// Mark step as completed
		$state = $this->get_wizard_state();
		$step_keys = array( 1 => 'settings', 2 => 'business', 3 => 'services', 4 => 'cities' );
		
		if ( isset( $step_keys[ $step ] ) ) {
			$state['steps_completed'][ $step_keys[ $step ] ] = true;
		}
		
		// Advance to next step
		$state['current_step'] = $step + 1;
		
		$this->update_wizard_state( $state );
		
		wp_send_json_success( array(
			'message' => 'Step completed',
			'next_step' => $step + 1,
		) );
	}
	
	/**
	 * AJAX: Start automated generation
	 */
	public function ajax_start_generation() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		// Get services and cities from cache
		$services = get_option( 'hyper_local_services_cache', array() );
		$cities = get_option( 'hyper_local_cities_cache', array() );
		$business_config = get_option( 'seogen_business_config', array() );
		$settings = get_option( 'seogen_settings', array() );
		
		if ( empty( $services ) || empty( $cities ) ) {
			wp_send_json_error( array( 'message' => 'No services or cities configured' ) );
		}
		
		$api_url = isset( $settings['api_url'] ) ? trim( $settings['api_url'] ) : '';
		$license_key = isset( $settings['license_key'] ) ? trim( $settings['license_key'] ) : '';
		
		if ( empty( $api_url ) || empty( $license_key ) ) {
			wp_send_json_error( array( 'message' => 'API settings not configured' ) );
		}
		
		// Build items for API
		$api_items = array();
		foreach ( $services as $service ) {
			$service_name = is_array( $service ) ? $service['name'] : $service;
			foreach ( $cities as $city ) {
				$city_name = is_array( $city ) ? $city['city'] : $city;
				$state = is_array( $city ) && isset( $city['state'] ) ? $city['state'] : '';
				
				$api_items[] = array(
					'service' => $service_name,
					'city' => $city_name,
					'state' => $state,
					'company_name' => isset( $business_config['business_name'] ) ? $business_config['business_name'] : '',
					'phone' => isset( $business_config['phone'] ) ? $business_config['phone'] : '',
					'email' => isset( $business_config['email'] ) ? $business_config['email'] : '',
					'address' => isset( $business_config['address'] ) ? $business_config['address'] : '',
				);
			}
		}
		
		// Call API to create bulk job
		require_once SEOGEN_PLUGIN_DIR . 'includes/class-seogen-admin.php';
		$admin = new SEOgen_Admin();
		
		$job_name = 'Wizard Generation - ' . current_time( 'Y-m-d H:i:s' );
		$result = $this->call_api_create_bulk_job( $admin, $api_url, $license_key, $job_name, $api_items );
		
		if ( ! $result['success'] ) {
			wp_send_json_error( array( 'message' => $result['error'] ) );
		}
		
		// Store job info in wizard state
		$this->update_wizard_state( array(
			'api_job_id' => $result['job_id'],
			'generation_status' => 'running',
			'total_pages' => count( $api_items ),
		) );
		
		wp_send_json_success( array(
			'message' => 'Generation started',
			'job_id' => $result['job_id'],
			'total' => count( $api_items ),
		) );
	}
	
	/**
	 * Call API to create bulk job using admin class method
	 */
	private function call_api_create_bulk_job( $admin, $api_url, $license_key, $job_name, $items ) {
		// Use reflection to call private method
		$method = new ReflectionMethod( $admin, 'api_create_bulk_job' );
		$method->setAccessible( true );
		$response = $method->invoke( $admin, $api_url, $license_key, $job_name, $items );
		
		if ( empty( $response['ok'] ) || ! is_array( $response['data'] ) || empty( $response['data']['job_id'] ) ) {
			return array(
				'success' => false,
				'error' => isset( $response['error'] ) ? $response['error'] : 'Failed to create bulk job',
			);
		}
		
		return array(
			'success' => true,
			'job_id' => $response['data']['job_id'],
		);
	}
	
	/**
	 * AJAX: Process generation batch - polls API and imports results
	 */
	public function ajax_process_batch() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$api_job_id = isset( $_POST['job_id'] ) ? sanitize_text_field( $_POST['job_id'] ) : '';
		if ( empty( $api_job_id ) ) {
			wp_send_json_error( array( 'message' => 'Job ID required' ) );
		}
		
		// Get settings
		$settings = get_option( 'seogen_settings', array() );
		$api_url = isset( $settings['api_url'] ) ? trim( $settings['api_url'] ) : '';
		$license_key = isset( $settings['license_key'] ) ? trim( $settings['license_key'] ) : '';
		
		// Get admin instance
		require_once SEOGEN_PLUGIN_DIR . 'includes/class-seogen-admin.php';
		$admin = new SEOgen_Admin();
		
		// Get job status from API
		$status_result = $this->call_api_get_job_status( $admin, $api_url, $license_key, $api_job_id );
		
		if ( ! $status_result['success'] ) {
			wp_send_json_error( array( 'message' => $status_result['error'] ) );
		}
		
		$status_data = $status_result['data'];
		$job_status = isset( $status_data['status'] ) ? $status_data['status'] : 'pending';
		$total = isset( $status_data['total_items'] ) ? (int) $status_data['total_items'] : 0;
		$completed = isset( $status_data['completed'] ) ? (int) $status_data['completed'] : 0;
		$failed = isset( $status_data['failed'] ) ? (int) $status_data['failed'] : 0;
		
		// Get wizard state to track imported pages
		$state = $this->get_wizard_state();
		$imported_count = isset( $state['imported_count'] ) ? (int) $state['imported_count'] : 0;
		$cursor = isset( $state['api_cursor'] ) ? $state['api_cursor'] : '';
		
		// Fetch results from API (batch of 10)
		$results_response = $this->call_api_get_job_results( $admin, $api_url, $license_key, $api_job_id, $cursor, 10 );
		
		$batch_results = array();
		$new_cursor = $cursor;
		$newly_imported = 0;
		
		if ( $results_response['success'] && ! empty( $results_response['items'] ) ) {
			$new_cursor = isset( $results_response['cursor'] ) ? $results_response['cursor'] : '';
			
			// Import each completed page
			foreach ( $results_response['items'] as $item ) {
				$item_status = isset( $item['status'] ) ? $item['status'] : '';
				
				if ( $item_status === 'completed' && isset( $item['result_json'] ) ) {
					$import_result = $this->import_page_from_api_result( $item, $admin );
					
					if ( $import_result['success'] ) {
						$newly_imported++;
						$batch_results[] = array(
							'success' => true,
							'service' => isset( $item['service'] ) ? $item['service'] : '',
							'city' => isset( $item['city'] ) ? $item['city'] : '',
							'post_id' => $import_result['post_id'],
						);
					} else {
						$batch_results[] = array(
							'success' => false,
							'service' => isset( $item['service'] ) ? $item['service'] : '',
							'city' => isset( $item['city'] ) ? $item['city'] : '',
							'error' => $import_result['error'],
						);
					}
				} elseif ( $item_status === 'failed' ) {
					$batch_results[] = array(
						'success' => false,
						'service' => isset( $item['service'] ) ? $item['service'] : '',
						'city' => isset( $item['city'] ) ? $item['city'] : '',
						'error' => isset( $item['error'] ) ? $item['error'] : 'Generation failed',
					);
				}
			}
		}
		
		// Update wizard state
		$imported_count += $newly_imported;
		$is_complete = ( $job_status === 'completed' || $job_status === 'complete' );
		
		$this->update_wizard_state( array(
			'imported_count' => $imported_count,
			'api_cursor' => $new_cursor,
			'generation_status' => $is_complete ? 'completed' : 'running',
			'completed' => $is_complete,
			'completed_at' => $is_complete ? current_time( 'mysql' ) : null,
		) );
		
		wp_send_json_success( array(
			'status' => $job_status,
			'total' => $total,
			'processed' => $completed + $failed,
			'successful' => $imported_count,
			'failed' => $failed,
			'batch_results' => $batch_results,
			'complete' => $is_complete,
		) );
	}
	
	/**
	 * Call API to get job status
	 */
	private function call_api_get_job_status( $admin, $api_url, $license_key, $api_job_id ) {
		$method = new ReflectionMethod( $admin, 'api_get_bulk_job_status' );
		$method->setAccessible( true );
		$response = $method->invoke( $admin, $api_url, $license_key, $api_job_id );
		
		if ( empty( $response['ok'] ) || ! is_array( $response['data'] ) ) {
			return array(
				'success' => false,
				'error' => isset( $response['error'] ) ? $response['error'] : 'Failed to get job status',
			);
		}
		
		return array(
			'success' => true,
			'data' => $response['data'],
		);
	}
	
	/**
	 * Call API to get job results
	 */
	private function call_api_get_job_results( $admin, $api_url, $license_key, $api_job_id, $cursor, $limit ) {
		$method = new ReflectionMethod( $admin, 'api_get_bulk_job_results' );
		$method->setAccessible( true );
		$response = $method->invoke( $admin, $api_url, $license_key, $api_job_id, $cursor, $limit );
		
		if ( empty( $response['ok'] ) || ! is_array( $response['data'] ) ) {
			return array(
				'success' => false,
				'error' => isset( $response['error'] ) ? $response['error'] : 'Failed to get results',
			);
		}
		
		return array(
			'success' => true,
			'items' => isset( $response['data']['items'] ) ? $response['data']['items'] : array(),
			'cursor' => isset( $response['data']['next_cursor'] ) ? $response['data']['next_cursor'] : '',
		);
	}
	
	/**
	 * Import a page from API result
	 */
	private function import_page_from_api_result( $item, $admin ) {
		$result_json = isset( $item['result_json'] ) ? $item['result_json'] : null;
		
		if ( ! is_array( $result_json ) ) {
			return array(
				'success' => false,
				'error' => 'Invalid result data',
			);
		}
		
		$title = isset( $result_json['title'] ) ? $result_json['title'] : '';
		$slug = isset( $result_json['slug'] ) ? $result_json['slug'] : '';
		$blocks = isset( $result_json['blocks'] ) && is_array( $result_json['blocks'] ) ? $result_json['blocks'] : array();
		$page_mode = isset( $result_json['page_mode'] ) ? $result_json['page_mode'] : '';
		
		// Use admin's method to build Gutenberg content
		$method = new ReflectionMethod( $admin, 'build_gutenberg_content_from_blocks' );
		$method->setAccessible( true );
		$content = $method->invoke( $admin, $blocks, $page_mode );
		
		// Create WordPress post
		$post_data = array(
			'post_title' => $title,
			'post_name' => $slug,
			'post_content' => $content,
			'post_status' => 'publish',
			'post_type' => 'service_page',
		);
		
		$post_id = wp_insert_post( $post_data );
		
		if ( is_wp_error( $post_id ) ) {
			return array(
				'success' => false,
				'error' => $post_id->get_error_message(),
			);
		}
		
		// Save metadata
		if ( isset( $item['service'] ) ) {
			update_post_meta( $post_id, '_hyper_local_service_name', $item['service'] );
		}
		if ( isset( $item['city'] ) ) {
			update_post_meta( $post_id, '_hyper_local_city_name', $item['city'] );
		}
		if ( isset( $item['state'] ) && ! empty( $item['state'] ) ) {
			update_post_meta( $post_id, '_hyper_local_state', $item['state'] );
		}
		
		return array(
			'success' => true,
			'post_id' => $post_id,
		);
	}
	
	/**
	 * AJAX: Get generation progress
	 */
	public function ajax_generation_progress() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$job_id = isset( $_POST['job_id'] ) ? sanitize_text_field( $_POST['job_id'] ) : '';
		if ( empty( $job_id ) ) {
			wp_send_json_error( array( 'message' => 'Job ID required' ) );
		}
		
		$job_data = get_transient( 'seogen_wizard_job_' . $job_id );
		if ( ! $job_data ) {
			wp_send_json_error( array( 'message' => 'Job not found' ) );
		}
		
		wp_send_json_success( array(
			'status' => $job_data['status'],
			'total' => $job_data['total'],
			'processed' => $job_data['processed'],
			'successful' => $job_data['successful'],
			'failed' => $job_data['failed'],
			'complete' => $job_data['status'] === 'completed',
		) );
	}
	
	/**
	 * AJAX: Skip generation
	 */
	public function ajax_skip_generation() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		// Mark wizard as completed without generation
		$this->update_wizard_state( array(
			'completed' => true,
		) );
		
		wp_send_json_success( array(
			'message' => 'Wizard completed',
			'redirect' => admin_url( 'admin.php?page=hyper-local' ),
		) );
	}
	
	/**
	 * AJAX: Dismiss wizard
	 */
	public function ajax_dismiss_wizard() {
		check_ajax_referer( 'seogen_wizard_dismiss', '_ajax_nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		update_option( self::WIZARD_DISMISSED_OPTION, true );
		
		wp_send_json_success( array(
			'message' => 'Wizard dismissed',
		) );
	}
	
	/**
	 * AJAX: Reset wizard
	 */
	public function ajax_reset_wizard() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$this->reset_wizard();
		
		wp_send_json_success( array(
			'message' => 'Wizard reset successfully',
			'redirect' => admin_url( 'admin.php?page=seogen-wizard' ),
		) );
	}
	
	/**
	 * Handle settings form submission
	 */
	public function handle_save_settings() {
		check_admin_referer( 'seogen_wizard_save_settings' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied' );
		}
		
		// Get posted data
		$settings = isset( $_POST['seogen_settings'] ) ? $_POST['seogen_settings'] : array();
		
		// Sanitize settings
		$sanitized = array(
			'api_url' => isset( $settings['api_url'] ) ? esc_url_raw( $settings['api_url'] ) : 'https://seogen-production.up.railway.app',
			'license_key' => isset( $settings['license_key'] ) ? sanitize_text_field( $settings['license_key'] ) : '',
		);
		
		// Save settings
		update_option( 'seogen_settings', $sanitized );
		
		// Return JSON for AJAX
		wp_send_json_success( array(
			'message' => 'Settings saved successfully',
		) );
	}
	
	/**
	 * Handle business config form submission
	 */
	public function handle_save_business() {
		check_admin_referer( 'seogen_wizard_save_business' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied' );
		}
		
		// Get posted data
		$config = isset( $_POST['seogen_business_config'] ) ? $_POST['seogen_business_config'] : array();
		
		// Sanitize hub categories
		$hub_categories = isset( $config['hub_categories'] ) && is_array( $config['hub_categories'] ) 
			? array_map( 'sanitize_text_field', $config['hub_categories'] ) 
			: array( 'residential', 'commercial' );
		
		// Sanitize config
		$sanitized = array(
			'vertical' => isset( $config['vertical'] ) ? sanitize_text_field( $config['vertical'] ) : '',
			'business_name' => isset( $config['business_name'] ) ? sanitize_text_field( $config['business_name'] ) : '',
			'phone' => isset( $config['phone'] ) ? sanitize_text_field( $config['phone'] ) : '',
			'email' => isset( $config['email'] ) ? sanitize_email( $config['email'] ) : '',
			'address' => isset( $config['address'] ) ? sanitize_text_field( $config['address'] ) : '',
			'cta_text' => isset( $config['cta_text'] ) ? sanitize_text_field( $config['cta_text'] ) : 'Request a Free Estimate',
			'service_area_label' => isset( $config['service_area_label'] ) ? sanitize_text_field( $config['service_area_label'] ) : '',
			'hub_categories' => $hub_categories,
		);
		
		// Save config
		update_option( 'seogen_business_config', $sanitized );
		
		// Return JSON for AJAX
		wp_send_json_success( array(
			'message' => 'Business config saved successfully',
		) );
	}
	
	/**
	 * AJAX: Add service
	 */
	public function ajax_add_service() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$service_name = isset( $_POST['service_name'] ) ? sanitize_text_field( $_POST['service_name'] ) : '';
		$service_hub = isset( $_POST['service_hub'] ) ? sanitize_text_field( $_POST['service_hub'] ) : '';
		
		if ( empty( $service_name ) ) {
			wp_send_json_error( array( 'message' => 'Service name is required' ) );
		}
		
		// Get existing services
		$services = get_option( 'hyper_local_services_cache', array() );
		if ( ! is_array( $services ) ) {
			$services = array();
		}
		
		// Add new service with hub category
		$new_service = array( 'name' => $service_name );
		if ( ! empty( $service_hub ) ) {
			$new_service['hub'] = $service_hub;
		}
		$services[] = $new_service;
		
		// Save services
		update_option( 'hyper_local_services_cache', $services );
		
		wp_send_json_success( array(
			'message' => 'Service added successfully',
			'count' => count( $services ),
		) );
	}
	
	/**
	 * AJAX: Bulk add services
	 */
	public function ajax_bulk_add_services() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$bulk_text = isset( $_POST['bulk_text'] ) ? sanitize_textarea_field( $_POST['bulk_text'] ) : '';
		
		if ( empty( $bulk_text ) ) {
			wp_send_json_error( array( 'message' => 'Bulk text is required' ) );
		}
		
		// Get existing services
		$services = get_option( 'hyper_local_services_cache', array() );
		if ( ! is_array( $services ) ) {
			$services = array();
		}
		
		// Get hub categories for default
		$config = get_option( 'seogen_business_config', array() );
		$hub_categories = isset( $config['hub_categories'] ) && is_array( $config['hub_categories'] ) 
			? $config['hub_categories'] 
			: array( 'residential', 'commercial' );
		$default_hub = ! empty( $hub_categories ) ? $hub_categories[0] : 'residential';
		
		// Parse bulk text
		$lines = explode( "\n", $bulk_text );
		$added_count = 0;
		
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( empty( $line ) ) {
				continue;
			}
			
			// Check if line has hub prefix (e.g., "residential: Service Name")
			if ( strpos( $line, ':' ) !== false ) {
				$parts = explode( ':', $line, 2 );
				$hub = trim( $parts[0] );
				$service_name = trim( $parts[1] );
				
				// Validate hub exists in configured hubs
				if ( in_array( $hub, $hub_categories ) && ! empty( $service_name ) ) {
					$services[] = array(
						'name' => $service_name,
						'hub' => $hub,
					);
					$added_count++;
				}
			} else {
				// No hub specified, use default
				$services[] = array(
					'name' => $line,
					'hub' => $default_hub,
				);
				$added_count++;
			}
		}
		
		// Save services
		update_option( 'hyper_local_services_cache', $services );
		
		wp_send_json_success( array(
			'message' => sprintf( '%d services added successfully', $added_count ),
			'count' => count( $services ),
			'added' => $added_count,
		) );
	}
	
	/**
	 * AJAX: Delete service
	 */
	public function ajax_delete_service() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$index = isset( $_POST['index'] ) ? intval( $_POST['index'] ) : -1;
		
		if ( $index < 0 ) {
			wp_send_json_error( array( 'message' => 'Invalid index' ) );
		}
		
		// Get existing services
		$services = get_option( 'hyper_local_services_cache', array() );
		if ( ! is_array( $services ) ) {
			$services = array();
		}
		
		// Remove service at index
		if ( isset( $services[ $index ] ) ) {
			array_splice( $services, $index, 1 );
			update_option( 'hyper_local_services_cache', $services );
			
			wp_send_json_success( array(
				'message' => 'Service deleted successfully',
				'count' => count( $services ),
			) );
		} else {
			wp_send_json_error( array( 'message' => 'Service not found' ) );
		}
	}
	
	/**
	 * AJAX: Add city
	 */
	public function ajax_add_city() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$city_name = isset( $_POST['city_name'] ) ? sanitize_text_field( $_POST['city_name'] ) : '';
		
		if ( empty( $city_name ) ) {
			wp_send_json_error( array( 'message' => 'City name is required' ) );
		}
		
		// Parse city and state
		$parts = array_map( 'trim', explode( ',', $city_name ) );
		$city = isset( $parts[0] ) ? $parts[0] : '';
		$state = isset( $parts[1] ) ? $parts[1] : '';
		
		// Validate that both city and state are provided
		if ( empty( $city ) || empty( $state ) ) {
			wp_send_json_error( array( 'message' => 'Please enter city in format: City Name, State (e.g., "Tulsa, OK")' ) );
		}
		
		// Validate state is 2 characters (state abbreviation)
		if ( strlen( $state ) !== 2 ) {
			wp_send_json_error( array( 'message' => 'Please use 2-letter state abbreviation (e.g., "OK", "TX", "NY")' ) );
		}
		
		// Get existing cities
		$cities = get_option( 'hyper_local_cities_cache', array() );
		if ( ! is_array( $cities ) ) {
			$cities = array();
		}
		
		// Add new city
		$cities[] = array(
			'name' => $city_name,
			'city' => $city,
			'state' => $state,
		);
		
		// Save cities
		update_option( 'hyper_local_cities_cache', $cities );
		
		wp_send_json_success( array(
			'message' => 'City added successfully',
			'count' => count( $cities ),
		) );
	}
	
	/**
	 * AJAX: Delete city
	 */
	public function ajax_delete_city() {
		check_ajax_referer( 'seogen_wizard', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}
		
		$index = isset( $_POST['index'] ) ? intval( $_POST['index'] ) : -1;
		
		if ( $index < 0 ) {
			wp_send_json_error( array( 'message' => 'Invalid index' ) );
		}
		
		// Get existing cities
		$cities = get_option( 'hyper_local_cities_cache', array() );
		if ( ! is_array( $cities ) ) {
			$cities = array();
		}
		
		// Remove city at index
		if ( isset( $cities[ $index ] ) ) {
			array_splice( $cities, $index, 1 );
			update_option( 'hyper_local_cities_cache', $cities );
			
			wp_send_json_success( array(
				'message' => 'City deleted successfully',
				'count' => count( $cities ),
			) );
		} else {
			wp_send_json_error( array( 'message' => 'City not found' ) );
		}
	}
}
