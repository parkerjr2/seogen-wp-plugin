<?php
/**
 * Background polling for bulk job completion
 * Uses Action Scheduler to poll backend API every 30 seconds
 * Runs independently of user sessions - no WP-Cron dependency
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait SEOgen_Background_Poller {
	
	const POLLER_HOOK = 'seogen_background_poll_job';
	const POLLER_GROUP = 'seogen-poller';
	
	/**
	 * Register background poller hooks
	 */
	public function register_background_poller() {
		// Hook to process background polling
		add_action( self::POLLER_HOOK, array( $this, 'background_poll_job' ), 10, 1 );
	}
	
	/**
	 * Schedule background polling for a job
	 * Called when bulk job starts
	 * 
	 * @param string $job_id Job ID to poll
	 */
	public function schedule_background_polling( $job_id ) {
		if ( ! function_exists( 'as_schedule_recurring_action' ) ) {
			file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] Action Scheduler not available, background polling disabled' . PHP_EOL, FILE_APPEND );
			return;
		}
		
		// Check if already scheduled
		$existing = as_next_scheduled_action( self::POLLER_HOOK, array( 'job_id' => $job_id ), self::POLLER_GROUP );
		if ( $existing ) {
			file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] Background polling already scheduled for job: ' . $job_id . PHP_EOL, FILE_APPEND );
			return;
		}
		
		// Schedule recurring action every 30 seconds
		$action_id = as_schedule_recurring_action(
			time(),
			30, // Run every 30 seconds
			self::POLLER_HOOK,
			array( 'job_id' => $job_id ),
			self::POLLER_GROUP
		);
		
		file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] Scheduled background polling for job: ' . $job_id . ' (action_id: ' . $action_id . ')' . PHP_EOL, FILE_APPEND );
	}
	
	/**
	 * Cancel background polling for a job
	 * Called when job completes
	 * 
	 * @param string $job_id Job ID
	 */
	public function cancel_background_polling( $job_id ) {
		if ( ! function_exists( 'as_unschedule_action' ) ) {
			return;
		}
		
		as_unschedule_action( self::POLLER_HOOK, array( 'job_id' => $job_id ), self::POLLER_GROUP );
		file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] Cancelled background polling for job: ' . $job_id . PHP_EOL, FILE_APPEND );
	}
	
	/**
	 * Background polling action - runs every 30 seconds via Action Scheduler
	 * 
	 * @param string $job_id Job ID to poll
	 */
	public function background_poll_job( $job_id ) {
		file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] [BACKGROUND POLL] Starting for job: ' . $job_id . PHP_EOL, FILE_APPEND );
		
		$job = $this->get_bulk_job( $job_id );
		if ( ! $job ) {
			file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] [BACKGROUND POLL] Job not found: ' . $job_id . PHP_EOL, FILE_APPEND );
			$this->cancel_background_polling( $job_id );
			return;
		}
		
		$job_status = isset( $job['status'] ) ? $job['status'] : '';
		
		// If job is already complete, cancel polling
		if ( 'complete' === $job_status && empty( $this->count_pending_imports( $job ) ) ) {
			file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] [BACKGROUND POLL] Job complete with no pending imports, cancelling polling: ' . $job_id . PHP_EOL, FILE_APPEND );
			$this->cancel_background_polling( $job_id );
			return;
		}
		
		// Poll backend for new results
		$this->poll_and_import_results( $job_id, $job );
		
		file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] [BACKGROUND POLL] Completed for job: ' . $job_id . PHP_EOL, FILE_APPEND );
	}
	
	/**
	 * Poll backend and import any new results
	 * Extracted from ajax_bulk_job_status for reuse
	 * 
	 * @param string $job_id Job ID
	 * @param array $job Job data
	 */
	private function poll_and_import_results( $job_id, $job ) {
		$settings = $this->get_settings();
		$api_url = isset( $settings['api_url'] ) ? $settings['api_url'] : '';
		$license_key = isset( $settings['license_key'] ) ? $settings['license_key'] : '';
		
		if ( empty( $api_url ) || empty( $license_key ) ) {
			return;
		}
		
		$api_job_id = isset( $job['api_job_id'] ) ? $job['api_job_id'] : '';
		if ( empty( $api_job_id ) ) {
			return;
		}
		
		// Count pending imports
		$pending_import_count = $this->count_pending_imports( $job );
		
		// Get API status
		$api_status = $this->get_api_job_status( $api_url, $license_key, $api_job_id );
		
		file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] [BACKGROUND POLL] pending_import_count=' . $pending_import_count . ' api_status=' . $api_status . PHP_EOL, FILE_APPEND );
		
		// Determine batch size based on job status
		$batch_size = ( 'complete' === $api_status ) ? 100 : 10;
		
		// Fetch results from backend
		$cursor = isset( $job['api_cursor'] ) ? $job['api_cursor'] : '';
		$results = $this->fetch_api_results( $api_url, $license_key, $api_job_id, $cursor, $batch_size );
		
		if ( ! $results || ! isset( $results['items'] ) ) {
			return;
		}
		
		$items = $results['items'];
		$next_cursor = isset( $results['next_cursor'] ) ? $results['next_cursor'] : null;
		
		file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] [BACKGROUND POLL] Fetched ' . count( $items ) . ' items from backend' . PHP_EOL, FILE_APPEND );
		
		// Process and import items
		if ( ! empty( $items ) ) {
			$this->process_bulk_results( $job_id, $job, $items );
			
			// Update cursor
			$job['api_cursor'] = $next_cursor;
			$this->save_bulk_job( $job_id, $job );
		}
		
		// Update job status if API is complete
		if ( 'complete' === $api_status && null === $next_cursor ) {
			$job['status'] = 'complete';
			$this->save_bulk_job( $job_id, $job );
			
			// Generate city hub content if not already done
			if ( ! isset( $job['city_hubs_generated'] ) && isset( $job['city_hub_map'] ) && ! empty( $job['city_hub_map'] ) ) {
				file_put_contents( WP_CONTENT_DIR . '/seogen-debug.log', '[' . date('Y-m-d H:i:s') . '] [BACKGROUND POLL] Starting city hub content generation' . PHP_EOL, FILE_APPEND );
				$this->generate_city_hub_content( $job_id, $job );
				$job['city_hubs_generated'] = true;
				$this->save_bulk_job( $job_id, $job );
			}
		}
	}
	
	/**
	 * Count pending imports in a job
	 * 
	 * @param array $job Job data
	 * @return int Number of pending imports
	 */
	private function count_pending_imports( $job ) {
		if ( ! isset( $job['rows'] ) || ! is_array( $job['rows'] ) ) {
			return 0;
		}
		
		$count = 0;
		foreach ( $job['rows'] as $row ) {
			$status = isset( $row['status'] ) ? $row['status'] : '';
			if ( 'pending' === $status || 'processing' === $status ) {
				$count++;
			}
		}
		
		return $count;
	}
	
	/**
	 * Get API job status
	 * 
	 * @param string $api_url API URL
	 * @param string $license_key License key
	 * @param string $api_job_id API job ID
	 * @return string Job status (running|complete|failed)
	 */
	private function get_api_job_status( $api_url, $license_key, $api_job_id ) {
		$url = trailingslashit( $api_url ) . 'bulk-jobs/' . $api_job_id . '/status';
		
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 10,
				'headers' => array(
					'X-License-Key' => $license_key,
				),
			)
		);
		
		if ( is_wp_error( $response ) ) {
			return 'running';
		}
		
		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return 'running';
		}
		
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		
		return isset( $data['status'] ) ? $data['status'] : 'running';
	}
	
	/**
	 * Fetch results from backend API
	 * 
	 * @param string $api_url API URL
	 * @param string $license_key License key
	 * @param string $api_job_id API job ID
	 * @param string $cursor Pagination cursor
	 * @param int $batch_size Batch size
	 * @return array|null Results array or null on error
	 */
	private function fetch_api_results( $api_url, $license_key, $api_job_id, $cursor, $batch_size ) {
		$url = trailingslashit( $api_url ) . 'bulk-jobs/' . $api_job_id . '/results';
		$url = add_query_arg(
			array(
				'cursor' => $cursor ? $cursor : '',
				'limit' => $batch_size,
			),
			$url
		);
		
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 30,
				'headers' => array(
					'X-License-Key' => $license_key,
				),
			)
		);
		
		if ( is_wp_error( $response ) ) {
			return null;
		}
		
		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return null;
		}
		
		$body = wp_remote_retrieve_body( $response );
		return json_decode( $body, true );
	}
}
